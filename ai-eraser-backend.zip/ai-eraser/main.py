"""
AI Eraser — main.py
FastAPI entry point with lifespan management.

This system follows data minimization and zero-retention principles.
All image data is processed in-memory and never persisted to disk.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from app.routers import analyze, redact, health
from app.engine.detection import DetectionEngine
from app.engine.redaction import RedactionEngine

# ── Logging ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
)
log = logging.getLogger("ai_eraser")


# ── Lifespan: warm up models once at startup ───────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("AI Eraser starting — loading detection models…")
    detection_engine = DetectionEngine()
    detection_engine.warmup()
    redaction_engine = RedactionEngine()

    # Store as app state so routers can access
    app.state.detection = detection_engine
    app.state.redaction = redaction_engine

    log.info("All models loaded — system ready")
    yield
    log.info("AI Eraser shutting down — releasing resources")


# ── App factory ────────────────────────────────────────────────────────────
def create_app() -> FastAPI:
    app = FastAPI(
        title="AI Eraser",
        version="1.0.0",
        description=(
            "Privacy-first AI redaction system. "
            "All processing is local — no image data leaves this server."
        ),
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # CORS — restrict in production
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],           # tighten for production
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["*"],
    )

    # Routers
    app.include_router(health.router,   prefix="/api")
    app.include_router(analyze.router,  prefix="/api")
    app.include_router(redact.router,   prefix="/api")

    # Serve static frontend
    try:
        app.mount("/static", StaticFiles(directory="static"), name="static")
    except RuntimeError:
        pass  # static dir may not exist in test environments

    @app.get("/", response_class=HTMLResponse, include_in_schema=False)
    async def index():
        try:
            with open("static/index.html", encoding="utf-8") as f:
                return f.read()
        except FileNotFoundError:
            return "<h1>AI Eraser API</h1><p><a href='/docs'>Docs</a></p>"

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

"""
tests/test_engines.py

Unit tests for:
  - DetectionEngine (determinism, coordinate clamping)
  - RiskScoringEngine (weights, combos, level classification)
  - RedactionEngine (all three modes, in-place correctness)
  - PostProcessor (IoU deduplication)
  - PatternModule (regex coverage)

Run: pytest tests/ -v
"""

from __future__ import annotations

import io
import numpy as np
import pytest
import cv2

from app.models import (
    BoundingBox, Detection, DetectionType, RedactionMode, RiskLevel,
)
from app.engine.risk import compute_risk
from app.engine.redaction import RedactionEngine
from app.engine.detection import (
    PostProcessor, PatternModule, _iou, _det_id, _clamp_bbox,
)


# ── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture
def blank_bgr():
    """300×200 white image."""
    return np.full((200, 300, 3), 255, dtype=np.uint8)


@pytest.fixture
def text_bgr():
    """Image with synthetic text for OCR tests."""
    img = np.full((100, 400, 3), 255, dtype=np.uint8)
    cv2.putText(img, "010-1234-5678", (10, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 0), 2)
    return img


@pytest.fixture
def det_face() -> Detection:
    return Detection(
        id="abc001", type=DetectionType.FACE, label="얼굴",
        bbox=BoundingBox(x=10, y=10, width=80, height=80),
        confidence=0.90, source="haarcascade",
    )


@pytest.fixture
def det_phone() -> Detection:
    return Detection(
        id="abc002", type=DetectionType.PHONE, label="전화번호",
        text="010-1234-5678",
        bbox=BoundingBox(x=5, y=100, width=200, height=30),
        confidence=0.95, source="pattern",
    )


@pytest.fixture
def det_id() -> Detection:
    return Detection(
        id="abc003", type=DetectionType.ID, label="주민등록번호",
        text="901231-1234567",
        bbox=BoundingBox(x=5, y=140, width=200, height=30),
        confidence=0.97, source="pattern",
    )


# ═══════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════

class TestHelpers:
    def test_iou_identical(self, det_face):
        assert _iou(det_face.bbox, det_face.bbox) == pytest.approx(1.0)

    def test_iou_no_overlap(self, det_face, det_phone):
        assert _iou(det_face.bbox, det_phone.bbox) == pytest.approx(0.0)

    def test_iou_partial(self):
        a = BoundingBox(x=0, y=0, width=100, height=100)
        b = BoundingBox(x=50, y=50, width=100, height=100)
        iou = _iou(a, b)
        assert 0.0 < iou < 1.0

    def test_det_id_deterministic(self):
        id1 = _det_id("face", 10, 20, 80, 80)
        id2 = _det_id("face", 10, 20, 80, 80)
        assert id1 == id2

    def test_det_id_distinct(self):
        assert _det_id("face", 10, 20, 80, 80) != _det_id("face", 11, 20, 80, 80)

    def test_clamp_bbox_within(self):
        assert _clamp_bbox(5, 5, 50, 50, 100, 100) == (5, 5, 50, 50)

    def test_clamp_bbox_overflow(self):
        x, y, w, h = _clamp_bbox(90, 90, 50, 50, 100, 100)
        assert x + w <= 100
        assert y + h <= 100


# ═══════════════════════════════════════════════════════════════════════════
# PostProcessor
# ═══════════════════════════════════════════════════════════════════════════

class TestPostProcessor:
    pp = PostProcessor()

    def test_removes_low_confidence(self, det_face):
        low = det_face.model_copy(update={"confidence": 0.1})
        result = self.pp.process([low], 300, 200)
        assert result == []

    def test_keeps_high_confidence(self, det_face):
        result = self.pp.process([det_face], 300, 200)
        assert len(result) == 1

    def test_dedup_overlapping(self, det_face):
        """Two nearly identical boxes → only one survives."""
        dup = det_face.model_copy(
            update={"id": "dup", "bbox": BoundingBox(x=12, y=12, width=78, height=78)}
        )
        result = self.pp.process([det_face, dup], 300, 200)
        assert len(result) == 1

    def test_keeps_non_overlapping(self, det_face, det_phone):
        result = self.pp.process([det_face, det_phone], 300, 300)
        assert len(result) == 2

    def test_clamps_to_image_bounds(self):
        d = Detection(
            id="x", type=DetectionType.FACE, label="얼굴",
            bbox=BoundingBox(x=280, y=180, width=100, height=100),   # overflows
            confidence=0.80, source="test",
        )
        result = self.pp.process([d], 300, 200)
        assert len(result) == 1
        b = result[0].bbox
        assert b.x + b.width  <= 300
        assert b.y + b.height <= 200


# ═══════════════════════════════════════════════════════════════════════════
# PatternModule
# ═══════════════════════════════════════════════════════════════════════════

class TestPatternModule:
    pm = PatternModule()

    def _words(self, text: str, x: int = 10, y: int = 10) -> list:
        return [{
            "text": text, "x": x, "y": y,
            "width": len(text) * 8, "height": 20, "conf": 0.95,
        }]

    def test_korean_phone(self):
        dets = self.pm.analyze(self._words("010-1234-5678"))
        assert any(d.type == DetectionType.PHONE for d in dets)

    def test_email(self):
        dets = self.pm.analyze(self._words("user@example.com"))
        assert any(d.type == DetectionType.EMAIL for d in dets)

    def test_ssn(self):
        dets = self.pm.analyze(self._words("901231-1234567"))
        assert any(d.type == DetectionType.ID for d in dets)

    def test_credit_card(self):
        dets = self.pm.analyze(self._words("4532-7153-3790-1861"))
        assert any(d.type == DetectionType.CARD for d in dets)

    def test_no_false_positive_normal_text(self):
        dets = self.pm.analyze(self._words("Hello World"))
        assert dets == []

    def test_empty_words(self):
        assert self.pm.analyze([]) == []

    def test_detection_id_deterministic(self):
        dets1 = self.pm.analyze(self._words("010-1234-5678"))
        dets2 = self.pm.analyze(self._words("010-1234-5678"))
        assert dets1[0].id == dets2[0].id

    def test_multi_line_grouping(self):
        words = [
            {"text": "010-1234", "x": 0,  "y": 10, "width": 80, "height": 20, "conf": 0.95},
            {"text": "-5678",    "x": 85, "y": 10, "width": 50, "height": 20, "conf": 0.95},
        ]
        dets = self.pm.analyze(words)
        assert any(d.type == DetectionType.PHONE for d in dets)


# ═══════════════════════════════════════════════════════════════════════════
# Risk Scoring
# ═══════════════════════════════════════════════════════════════════════════

class TestRiskScoring:
    def test_empty(self):
        r = compute_risk([])
        assert r.score == 0
        assert r.level == RiskLevel.SAFE

    def test_safe_level(self, det_face):
        r = compute_risk([det_face])
        # face(20) × 0.90 = 18 → SAFE
        assert r.score <= 30
        assert r.level == RiskLevel.SAFE

    def test_danger_level(self, det_face, det_id):
        r = compute_risk([det_face, det_id])
        # face(18) + id(38.8) + combo(18) = 74.8 → DANGER
        assert r.score >= 71
        assert r.level == RiskLevel.DANGER

    def test_warning_level(self, det_phone):
        r = compute_risk([det_phone])
        # phone(25) × 0.95 = 23.75 → SAFE (only one)
        # add email to push into WARNING
        det_email = Detection(
            id="e1", type=DetectionType.EMAIL, label="이메일",
            bbox=BoundingBox(x=0, y=0, width=100, height=20),
            confidence=0.95, source="pattern",
        )
        r2 = compute_risk([det_phone, det_email])
        assert 0 <= r2.score <= 100

    def test_score_capped_at_100(self, det_face, det_phone, det_id):
        # Stack many high-weight detections
        dets = [det_face, det_phone, det_id] * 5
        r = compute_risk(dets)
        assert r.score <= 100

    def test_breakdown_populated(self, det_face):
        r = compute_risk([det_face])
        assert "face" in r.breakdown


# ═══════════════════════════════════════════════════════════════════════════
# RedactionEngine
# ═══════════════════════════════════════════════════════════════════════════

class TestRedactionEngine:
    engine = RedactionEngine()

    def _det(self, x=50, y=50, w=100, h=80) -> Detection:
        return Detection(
            id="r1", type=DetectionType.FACE, label="얼굴",
            bbox=BoundingBox(x=x, y=y, width=w, height=h),
            confidence=0.9, source="test", selected=True,
        )

    def test_does_not_mutate_original(self, blank_bgr):
        original = blank_bgr.copy()
        det = self._det()
        _ = self.engine.apply(blank_bgr, [det], RedactionMode.BLUR)
        assert np.array_equal(blank_bgr, original)

    def test_blur_changes_region(self, blank_bgr):
        """Draw a black rectangle; blur should change pixels in that region."""
        img = blank_bgr.copy()
        img[50:130, 50:150] = 0   # black box
        det = self._det()
        out = self.engine.apply(img, [det], RedactionMode.BLUR)
        roi_in  = img[50:130, 50:150]
        roi_out = out[50:130, 50:150]
        assert not np.array_equal(roi_in, roi_out)

    def test_pixelate_changes_region(self, blank_bgr):
        img = blank_bgr.copy()
        img[50:130, 50:150] = [0, 128, 255]
        det = self._det()
        out = self.engine.apply(img, [det], RedactionMode.PIXELATE)
        assert out.shape == img.shape

    def test_mosaic_changes_region(self, blank_bgr):
        img = blank_bgr.copy()
        img[50:130, 50:150] = [200, 50, 10]
        det = self._det()
        out = self.engine.apply(img, [det], RedactionMode.MOSAIC)
        assert out.shape == img.shape

    def test_unselected_detection_skipped(self, blank_bgr):
        img = blank_bgr.copy()
        img[50:130, 50:150] = 0
        det = self._det()
        det_unselected = det.model_copy(update={"selected": False})
        out = self.engine.apply(img, [det_unselected], RedactionMode.BLUR)
        # Region should NOT be changed (unselected)
        assert np.array_equal(out[50:130, 50:150], img[50:130, 50:150])

    def test_out_of_bounds_bbox_safe(self, blank_bgr):
        """Bbox exceeding image bounds should not raise — just be clamped."""
        det = self._det(x=280, y=180, w=200, h=200)  # overflows 300×200
        out = self.engine.apply(blank_bgr, [det], RedactionMode.BLUR)
        assert out.shape == blank_bgr.shape

    def test_deterministic_blur(self, blank_bgr):
        """Same image + same params → identical output."""
        img = blank_bgr.copy()
        img[50:130, 50:150] = 42
        det = self._det()
        out1 = self.engine.apply(img, [det], RedactionMode.BLUR, blur_strength=25)
        out2 = self.engine.apply(img, [det], RedactionMode.BLUR, blur_strength=25)
        assert np.array_equal(out1, out2)

    def test_deterministic_mosaic(self, blank_bgr):
        img = blank_bgr.copy()
        img[50:130, 50:150] = [100, 150, 200]
        det = self._det()
        out1 = self.engine.apply(img, [det], RedactionMode.MOSAIC, pixel_size=15)
        out2 = self.engine.apply(img, [det], RedactionMode.MOSAIC, pixel_size=15)
        assert np.array_equal(out1, out2)

    def test_multiple_detections(self, blank_bgr):
        img = blank_bgr.copy()
        dets = [
            self._det(x=10,  y=10,  w=60, h=60),
            self._det(x=200, y=120, w=60, h=60),
        ]
        out = self.engine.apply(img, dets, RedactionMode.PIXELATE)
        assert out.shape == img.shape

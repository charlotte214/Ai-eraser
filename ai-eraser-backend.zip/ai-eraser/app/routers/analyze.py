"""
app/routers/analyze.py
POST /api/analyze — accept image, return detections + risk score.

Security: image bytes are never written to disk.
          They live only in the request buffer and are GC'd after response.
"""

from __future__ import annotations

import time
import logging

from fastapi import APIRouter, File, HTTPException, Request, UploadFile, status
from fastapi.responses import JSONResponse

from app.engine.risk import compute_risk
from app.engine.utils import bytes_to_bgr
from app.models import AnalyzeResponse

log    = logging.getLogger("ai_eraser.analyze")
router = APIRouter(tags=["Detection"])

MAX_UPLOAD_BYTES = 20 * 1024 * 1024   # 20 MB hard limit


@router.post(
    "/analyze",
    response_model = AnalyzeResponse,
    summary        = "Detect sensitive information in an image",
    description    = (
        "Runs face detection + OCR + pattern analysis locally. "
        "The image is never stored or forwarded to external services."
    ),
)
async def analyze(
    request: Request,
    file:    UploadFile = File(..., description="JPEG, PNG, or WEBP image"),
):
    t0 = time.perf_counter()

    # ── Validate content type ────────────────────────────────────────────
    ct = (file.content_type or "").lower()
    if ct not in {"image/jpeg", "image/png", "image/webp", "image/jpg"}:
        raise HTTPException(
            status_code = status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail      = f"Unsupported image type: {ct}. Use JPEG, PNG, or WEBP.",
        )

    # ── Read image bytes (in-memory only) ────────────────────────────────
    raw = await file.read()
    if len(raw) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code = status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail      = f"Image exceeds {MAX_UPLOAD_BYTES // 1024 // 1024} MB limit.",
        )

    try:
        bgr = bytes_to_bgr(raw)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail=str(exc))
    finally:
        del raw        # immediately release upload buffer

    # ── Run detection pipeline ───────────────────────────────────────────
    engine = request.app.state.detection
    try:
        detections, img_w, img_h = engine.run(bgr)
    except Exception as exc:
        log.error(f"Detection error: {exc}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Detection failed: {exc}")
    finally:
        del bgr        # release image buffer

    # ── Score ────────────────────────────────────────────────────────────
    risk = compute_risk(detections)
    ms   = (time.perf_counter() - t0) * 1000

    log.info(
        f"analyze: {file.filename} → {len(detections)} detections, "
        f"score={risk.score} [{risk.level}], {ms:.0f} ms"
    )

    return AnalyzeResponse(
        detections    = detections,
        risk          = risk,
        image_width   = img_w,
        image_height  = img_h,
        processing_ms = round(ms, 1),
    )

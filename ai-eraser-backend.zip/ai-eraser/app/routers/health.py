"""app/routers/health.py"""
from fastapi import APIRouter, Request
from app.models import HealthResponse

router = APIRouter(tags=["System"])


@router.get("/health", response_model=HealthResponse)
async def health(request: Request):
    """System health + loaded model status."""
    de = request.app.state.detection
    return HealthResponse(
        status        = "ok",
        face_detector = de.face._source,
        ocr_available = de.ocr.is_available(),
    )

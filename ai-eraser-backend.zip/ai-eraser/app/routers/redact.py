"""
app/routers/redact.py
POST /api/redact — apply redaction to selected detection regions.

Security: processed image is streamed directly from memory.
          No temporary files are created on disk.
"""

from __future__ import annotations

import json
import logging
import time

from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile, status
from fastapi.responses import Response

from app.engine.utils import bytes_to_bgr, bgr_to_png_bytes
from app.models import Detection, RedactRequest, RedactionMode

log    = logging.getLogger("ai_eraser.redact")
router = APIRouter(tags=["Redaction"])

MAX_UPLOAD_BYTES = 20 * 1024 * 1024


@router.post(
    "/redact",
    responses={
        200: {
            "content":     {"image/png": {}},
            "description": "Redacted image (PNG)",
        }
    },
    summary     = "Apply privacy redaction to detected regions",
    description = (
        "Accepts the original image + detection list from /analyze. "
        "Returns the redacted image as PNG. Image never written to disk."
    ),
)
async def redact(
    request:    Request,
    file:       UploadFile = File(..., description="Original image"),
    detections: str        = Form(..., description="JSON array of Detection objects from /analyze"),
    mode:       str        = Form(default="blur",    description="blur | pixelate | mosaic"),
    blur_strength: int     = Form(default=25,        description="Blur sigma (5–80)"),
    pixel_size:    int     = Form(default=15,        description="Block size for pixelate/mosaic"),
):
    t0 = time.perf_counter()

    # ── Parse & validate redaction request ──────────────────────────────
    try:
        dets_raw = json.loads(detections)
        det_objs = [Detection.model_validate(d) for d in dets_raw]
    except Exception as exc:
        raise HTTPException(
            status_code = status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail      = f"Invalid detections JSON: {exc}",
        )

    try:
        rmode = RedactionMode(mode)
    except ValueError:
        raise HTTPException(
            status_code = status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail      = f"Invalid mode '{mode}'. Use: blur | pixelate | mosaic",
        )

    blur_strength = max(5, min(80, blur_strength))
    pixel_size    = max(5, min(50, pixel_size))

    # ── Read image ───────────────────────────────────────────────────────
    raw = await file.read()
    if len(raw) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code = status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail      = "Image exceeds 20 MB limit.",
        )

    try:
        bgr = bytes_to_bgr(raw)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    finally:
        del raw

    # ── Apply redaction (in-memory) ──────────────────────────────────────
    engine = request.app.state.redaction
    try:
        redacted = engine.apply(
            bgr,
            detections    = det_objs,
            mode          = rmode,
            blur_strength = blur_strength,
            pixel_size    = pixel_size,
        )
    except Exception as exc:
        log.error(f"Redaction error: {exc}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Redaction failed: {exc}")
    finally:
        del bgr

    # ── Encode result to PNG bytes ───────────────────────────────────────
    try:
        png_bytes = bgr_to_png_bytes(redacted)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    finally:
        del redacted

    ms = (time.perf_counter() - t0) * 1000
    selected = sum(1 for d in det_objs if d.selected)
    log.info(
        f"redact: mode={mode} selected={selected}/{len(det_objs)} "
        f"blur={blur_strength} pixel={pixel_size} → {len(png_bytes)//1024}KB  {ms:.0f} ms"
    )

    return Response(
        content      = png_bytes,
        media_type   = "image/png",
        headers      = {
            "X-Processing-Ms":   str(round(ms, 1)),
            "X-Detections-Count": str(selected),
            "Cache-Control":     "no-store",          # never cache sensitive output
        },
    )

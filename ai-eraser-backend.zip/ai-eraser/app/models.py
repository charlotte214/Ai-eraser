"""
app/models.py
Pydantic schemas for request/response contracts.
"""

from __future__ import annotations

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator


# ── Enumerations ───────────────────────────────────────────────────────────

class DetectionType(str, Enum):
    FACE    = "face"
    PHONE   = "phone"
    EMAIL   = "email"
    ID      = "id"
    CARD    = "card"
    ADDRESS = "address"
    TEXT    = "text"


class RiskLevel(str, Enum):
    SAFE    = "SAFE"
    WARNING = "WARNING"
    DANGER  = "DANGER"


class RedactionMode(str, Enum):
    BLUR      = "blur"
    PIXELATE  = "pixelate"
    MOSAIC    = "mosaic"


# ── Detection output ───────────────────────────────────────────────────────

class BoundingBox(BaseModel):
    x:      int = Field(..., ge=0, description="Left edge in canvas pixels")
    y:      int = Field(..., ge=0, description="Top edge in canvas pixels")
    width:  int = Field(..., gt=0)
    height: int = Field(..., gt=0)


class Detection(BaseModel):
    id:         str            = Field(..., description="Unique detection ID (deterministic)")
    type:       DetectionType
    label:      str            = Field(..., description="Human-readable label (Korean)")
    text:       Optional[str]  = Field(None, description="Extracted text (OCR detections)")
    bbox:       BoundingBox
    confidence: float          = Field(..., ge=0.0, le=1.0)
    source:     str            = Field(..., description="'mediapipe' | 'haarcascade' | 'tesseract' | 'pattern'")
    selected:   bool           = True

    @field_validator("confidence")
    @classmethod
    def round_conf(cls, v: float) -> float:
        return round(v, 4)


# ── Risk scoring ───────────────────────────────────────────────────────────

class RiskScore(BaseModel):
    score:       int       = Field(..., ge=0, le=100)
    level:       RiskLevel
    label_ko:    str       = Field(..., description="Korean label")
    breakdown:   dict      = Field(default_factory=dict)


# ── API responses ──────────────────────────────────────────────────────────

class AnalyzeResponse(BaseModel):
    """Response from POST /api/analyze"""
    detections:   List[Detection]
    risk:         RiskScore
    image_width:  int
    image_height: int
    processing_ms: float


class RedactRequest(BaseModel):
    """Body for POST /api/redact"""
    detections:    List[Detection] = Field(..., description="Detections to redact (only selected=True)")
    mode:          RedactionMode   = RedactionMode.BLUR
    blur_strength: int             = Field(default=25, ge=5, le=80, description="Blur kernel radius")
    pixel_size:    int             = Field(default=15, ge=5, le=50, description="Pixelate/mosaic block size")


class HealthResponse(BaseModel):
    status:         str
    face_detector:  str
    ocr_available:  bool
    version:        str = "1.0.0"

"""
app/engine/redaction.py

RedactionEngine — applies privacy redaction to detected regions.

Three modes:
  blur      — Gaussian blur (cv2.GaussianBlur)
  pixelate  — Downscale × Upscale with nearest-neighbor interpolation
  mosaic    — Average-color block fill

Design:
  • All operations are in IMAGE PIXEL SPACE — no CSS, no display scaling
  • Fully deterministic — same inputs → same output every time
  • No random behavior
  • In-memory only — no disk I/O

This system follows data minimization and zero-retention principles.
"""

from __future__ import annotations

import logging
from typing import List

import cv2
import numpy as np

from app.models import BoundingBox, Detection, RedactionMode

log = logging.getLogger("ai_eraser.redaction")


# ── Per-mode defaults ────────────────────────────────────────────────────────
_DEFAULT_BLUR_STRENGTH = 25   # sigma for GaussianBlur
_DEFAULT_PIXEL_SIZE    = 15   # block size for pixelate / mosaic


def _clamp(x: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, x))


class RedactionEngine:
    """
    Apply redaction to a region of an image.

    All bbox coordinates are in the original image's pixel space.
    The engine does NOT perform any display-space scaling.
    """

    def apply(
        self,
        bgr:           np.ndarray,
        detections:    List[Detection],
        mode:          RedactionMode = RedactionMode.BLUR,
        blur_strength: int           = _DEFAULT_BLUR_STRENGTH,
        pixel_size:    int           = _DEFAULT_PIXEL_SIZE,
    ) -> np.ndarray:
        """
        Returns a new numpy array with redacted regions.
        Original array is NOT mutated.
        """
        out    = bgr.copy()
        h, w   = out.shape[:2]
        applied = 0

        for det in detections:
            if not det.selected:
                continue
            bbox = det.bbox
            if not self._validate_bbox(bbox, w, h):
                log.warning(f"Skipping invalid bbox {bbox} for image {w}×{h}")
                continue

            roi = self._extract_roi(out, bbox)
            if roi.size == 0:
                continue

            redacted = self._redact_roi(roi, mode, blur_strength, pixel_size)
            self._paste_roi(out, redacted, bbox)
            applied += 1

        log.info(
            f"RedactionEngine: applied {applied}/{len(detections)} redactions "
            f"(mode={mode.value} blur={blur_strength} pixel={pixel_size})"
        )
        return out

    # ── Private helpers ────────────────────────────────────────────────────

    @staticmethod
    def _validate_bbox(bbox: BoundingBox, img_w: int, img_h: int) -> bool:
        return (
            0 <= bbox.x < img_w
            and 0 <= bbox.y < img_h
            and bbox.width  > 0
            and bbox.height > 0
        )

    @staticmethod
    def _extract_roi(img: np.ndarray, bbox: BoundingBox) -> np.ndarray:
        h, w   = img.shape[:2]
        x1     = _clamp(bbox.x,                   0, w)
        y1     = _clamp(bbox.y,                   0, h)
        x2     = _clamp(bbox.x + bbox.width,      0, w)
        y2     = _clamp(bbox.y + bbox.height,      0, h)
        return img[y1:y2, x1:x2]

    @staticmethod
    def _paste_roi(img: np.ndarray, roi: np.ndarray, bbox: BoundingBox) -> None:
        h, w   = img.shape[:2]
        x1     = _clamp(bbox.x,              0, w)
        y1     = _clamp(bbox.y,              0, h)
        x2     = x1 + roi.shape[1]
        y2     = y1 + roi.shape[0]
        x2     = _clamp(x2, 0, w)
        y2     = _clamp(y2, 0, h)
        img[y1:y2, x1:x2] = roi[:y2-y1, :x2-x1]

    def _redact_roi(
        self,
        roi:           np.ndarray,
        mode:          RedactionMode,
        blur_strength: int,
        pixel_size:    int,
    ) -> np.ndarray:
        if mode == RedactionMode.BLUR:
            return self._blur(roi, blur_strength)
        elif mode == RedactionMode.PIXELATE:
            return self._pixelate(roi, pixel_size)
        elif mode == RedactionMode.MOSAIC:
            return self._mosaic(roi, pixel_size)
        return roi  # fallback: no-op

    # ── Mode 1: Gaussian Blur ──────────────────────────────────────────────
    @staticmethod
    def _blur(roi: np.ndarray, strength: int) -> np.ndarray:
        """
        Apply Gaussian blur.
        Kernel size must be odd; strength is the sigma value.
        """
        sigma  = max(5, strength)
        ksize  = sigma * 4 + 1  # covers ~4σ on each side
        ksize  = ksize + 1 if ksize % 2 == 0 else ksize
        return cv2.GaussianBlur(roi, (ksize, ksize), sigmaX=sigma, sigmaY=sigma)

    # ── Mode 2: Pixelate ───────────────────────────────────────────────────
    @staticmethod
    def _pixelate(roi: np.ndarray, block_size: int) -> np.ndarray:
        """
        Downscale then upscale with nearest-neighbor — creates block effect.
        """
        h, w = roi.shape[:2]
        bs   = max(4, block_size)
        # Compute small dimensions (at least 1×1)
        sw   = max(1, w // bs)
        sh   = max(1, h // bs)
        small   = cv2.resize(roi,   (sw, sh), interpolation=cv2.INTER_LINEAR)
        pixeled = cv2.resize(small, (w,  h),  interpolation=cv2.INTER_NEAREST)
        return pixeled

    # ── Mode 3: Mosaic (average color per block) ───────────────────────────
    @staticmethod
    def _mosaic(roi: np.ndarray, block_size: int) -> np.ndarray:
        """
        Fill each block with the average color of that block.
        """
        h, w = roi.shape[:2]
        bs   = max(4, block_size)
        out  = roi.copy()
        for y in range(0, h, bs):
            for x in range(0, w, bs):
                y2   = min(y + bs, h)
                x2   = min(x + bs, w)
                block = roi[y:y2, x:x2]
                avg   = block.mean(axis=(0, 1)).astype(np.uint8)
                out[y:y2, x:x2] = avg  # broadcast to fill block
        return out

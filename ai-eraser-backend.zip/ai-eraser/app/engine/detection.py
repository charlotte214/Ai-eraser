"""
app/engine/detection.py

DetectionEngine — orchestrates all detection modules:
  ① FaceModule     — Mediapipe face detection with Haarcascade fallback
  ② OCRModule      — Tesseract OCR with word-level bounding boxes
  ③ PatternModule  — Regex sensitive-info matching on OCR output
  ④ PostProcessor  — Merge overlapping boxes, remove low-confidence hits

Design principles:
  • All processing is in-memory only (zero-retention)
  • Fully deterministic — same image → identical detections every run
  • No external network calls, no API keys, no cloud services
"""

from __future__ import annotations

import hashlib
import logging
import re
import time
from dataclasses import dataclass
from typing import List, Optional, Tuple

import cv2
import numpy as np

from app.models import BoundingBox, Detection, DetectionType

log = logging.getLogger("ai_eraser.detection")

# ── Try optional heavy deps (graceful fallback) ──────────────────────────
try:
    import mediapipe as mp
    _MP_AVAILABLE = True
except ImportError:
    _MP_AVAILABLE = False
    log.warning("mediapipe not installed — using Haarcascade face detector")

try:
    import pytesseract
    _TESS_AVAILABLE = True
except ImportError:
    _TESS_AVAILABLE = False
    log.warning("pytesseract not installed — OCR disabled")


# ═══════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _det_id(dtype: str, x: int, y: int, w: int, h: int) -> str:
    """Deterministic ID from detection geometry — same inputs → same ID."""
    raw = f"{dtype}:{x}:{y}:{w}:{h}"
    return hashlib.md5(raw.encode()).hexdigest()[:12]


def _clamp_bbox(x: int, y: int, w: int, h: int,
                img_w: int, img_h: int) -> Tuple[int, int, int, int]:
    x = max(0, min(x, img_w - 1))
    y = max(0, min(y, img_h - 1))
    w = max(1, min(w, img_w - x))
    h = max(1, min(h, img_h - y))
    return x, y, w, h


def _iou(a: BoundingBox, b: BoundingBox) -> float:
    """Intersection over Union for two bounding boxes."""
    ix0 = max(a.x, b.x)
    iy0 = max(a.y, b.y)
    ix1 = min(a.x + a.width,  b.x + b.width)
    iy1 = min(a.y + a.height, b.y + b.height)
    iw  = max(0, ix1 - ix0)
    ih  = max(0, iy1 - iy0)
    inter = iw * ih
    if inter == 0:
        return 0.0
    union = a.width * a.height + b.width * b.height - inter
    return inter / union if union else 0.0


# ═══════════════════════════════════════════════════════════════════════════
# Module 1 — Face Detection
# ═══════════════════════════════════════════════════════════════════════════

class FaceModule:
    """
    Detect human faces using Mediapipe (preferred) or OpenCV Haarcascade.
    Outputs bounding boxes in image pixel coordinates.
    """

    CONFIDENCE_THRESHOLD = 0.5

    def __init__(self) -> None:
        self._detector = None
        self._cascade:  Optional[cv2.CascadeClassifier] = None
        self._source = "none"

    def load(self) -> None:
        if _MP_AVAILABLE:
            self._load_mediapipe()
        else:
            self._load_haarcascade()

    def _load_mediapipe(self) -> None:
        try:
            mp_face = mp.solutions.face_detection  # type: ignore[attr-defined]
            self._detector = mp_face.FaceDetection(
                model_selection=1,               # 1 = full-range model (≤5 m)
                min_detection_confidence=self.CONFIDENCE_THRESHOLD,
            )
            self._source = "mediapipe"
            log.info("FaceModule: Mediapipe loaded (full-range model)")
        except Exception as exc:
            log.warning(f"FaceModule: Mediapipe init failed ({exc}) — Haarcascade fallback")
            self._load_haarcascade()

    def _load_haarcascade(self) -> None:
        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        clf = cv2.CascadeClassifier(cascade_path)
        if clf.empty():
            log.error("FaceModule: Haarcascade XML not found — face detection disabled")
            return
        self._cascade = clf
        self._source  = "haarcascade"
        log.info("FaceModule: Haarcascade loaded")

    def detect(self, bgr: np.ndarray) -> List[Detection]:
        if self._source == "mediapipe" and self._detector is not None:
            return self._detect_mediapipe(bgr)
        if self._source == "haarcascade" and self._cascade is not None:
            return self._detect_haarcascade(bgr)
        return []

    def _detect_mediapipe(self, bgr: np.ndarray) -> List[Detection]:
        """Mediapipe expects RGB."""
        h, w = bgr.shape[:2]
        rgb  = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        result = self._detector.process(rgb)
        detections: List[Detection] = []
        if not result.detections:
            return detections
        for det in result.detections:
            score = det.score[0] if det.score else 0.0
            if score < self.CONFIDENCE_THRESHOLD:
                continue
            box = det.location_data.relative_bounding_box
            # Convert relative → absolute pixel coords
            bx = int(box.xmin * w)
            by = int(box.ymin * h)
            bw = int(box.width  * w)
            bh = int(box.height * h)
            bx, by, bw, bh = _clamp_bbox(bx, by, bw, bh, w, h)
            detections.append(Detection(
                id         = _det_id("face", bx, by, bw, bh),
                type       = DetectionType.FACE,
                label      = "얼굴",
                bbox       = BoundingBox(x=bx, y=by, width=bw, height=bh),
                confidence = round(float(score), 4),
                source     = "mediapipe",
            ))
        return detections

    def _detect_haarcascade(self, bgr: np.ndarray) -> List[Detection]:
        """Haarcascade needs grayscale."""
        h, w = bgr.shape[:2]
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)  # improve contrast
        faces = self._cascade.detectMultiScale(
            gray,
            scaleFactor  = 1.1,
            minNeighbors = 5,
            minSize      = (30, 30),
            flags        = cv2.CASCADE_SCALE_IMAGE,
        )
        detections: List[Detection] = []
        if not isinstance(faces, np.ndarray) or len(faces) == 0:
            return detections
        for (fx, fy, fw, fh) in faces:
            fx, fy, fw, fh = _clamp_bbox(int(fx), int(fy), int(fw), int(fh), w, h)
            detections.append(Detection(
                id         = _det_id("face", fx, fy, fw, fh),
                type       = DetectionType.FACE,
                label      = "얼굴",
                bbox       = BoundingBox(x=fx, y=fy, width=fw, height=fh),
                confidence = 0.80,          # Haarcascade has no per-detection score
                source     = "haarcascade",
            ))
        return detections


# ═══════════════════════════════════════════════════════════════════════════
# Module 2 — OCR Module
# ═══════════════════════════════════════════════════════════════════════════

class OCRModule:
    """
    Extract text from an image using Tesseract.
    Returns word-level bounding boxes for downstream pattern matching.
    """

    CONFIDENCE_THRESHOLD = 60  # Tesseract confidence 0–100

    def is_available(self) -> bool:
        return _TESS_AVAILABLE

    def extract(self, bgr: np.ndarray) -> List[dict]:
        """
        Returns list of word records:
            { text, x, y, width, height, conf }
        """
        if not _TESS_AVAILABLE:
            return []

        # Preprocessing for better OCR
        gray   = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        # Adaptive thresholding improves text extraction on varied backgrounds
        thresh = cv2.adaptiveThreshold(
            gray, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 11, 2,
        )

        # Tesseract config: page segmentation mode 3 (auto), OEM 3 (LSTM+legacy)
        config = "--oem 3 --psm 3 -l eng+kor"
        try:
            data = pytesseract.image_to_data(
                thresh,
                config     = config,
                output_type= pytesseract.Output.DICT,
            )
        except Exception as exc:
            log.warning(f"OCRModule: Tesseract failed — {exc}")
            return []

        words = []
        n = len(data["text"])
        h_img, w_img = bgr.shape[:2]
        for i in range(n):
            text = str(data["text"][i]).strip()
            conf = int(data["conf"][i])
            if not text or conf < self.CONFIDENCE_THRESHOLD:
                continue
            wx = int(data["left"][i])
            wy = int(data["top"][i])
            ww = int(data["width"][i])
            wh = int(data["height"][i])
            if ww <= 0 or wh <= 0:
                continue
            wx, wy, ww, wh = _clamp_bbox(wx, wy, ww, wh, w_img, h_img)
            words.append({
                "text":   text,
                "x":      wx, "y":  wy,
                "width":  ww, "height": wh,
                "conf":   conf / 100.0,
            })
        log.debug(f"OCRModule: extracted {len(words)} words")
        return words


# ═══════════════════════════════════════════════════════════════════════════
# Module 3 — Sensitive Pattern Analyzer
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class _Pattern:
    dtype:   DetectionType
    label:   str
    regex:   re.Pattern
    conf:    float          # base confidence when matched


_PATTERNS: List[_Pattern] = [
    # ── Korean phone numbers ─────────────────────────────────────────
    _Pattern(
        dtype = DetectionType.PHONE,
        label = "전화번호",
        regex = re.compile(
            r"(\+?82[\s\-]?)?0(1[016789]|2|[3-9]\d{0,2})[\s\-]?\d{3,4}[\s\-]?\d{4}"
            r"|"
            r"\+\d{1,3}[\s\-]?\(?\d{1,4}\)?[\s\-]?\d{2,4}[\s\-]?\d{4}",
        ),
        conf  = 0.92,
    ),
    # ── Email ────────────────────────────────────────────────────────
    _Pattern(
        dtype = DetectionType.EMAIL,
        label = "이메일",
        regex = re.compile(
            r"[a-zA-Z0-9._%+\-]{1,64}@[a-zA-Z0-9.\-]{1,253}\.[a-zA-Z]{2,}",
        ),
        conf  = 0.95,
    ),
    # ── Korean SSN (주민등록번호) — 6 + 7 digits ─────────────────────
    _Pattern(
        dtype = DetectionType.ID,
        label = "주민등록번호",
        regex = re.compile(r"\d{6}[\s\-]?[1-4]\d{6}"),
        conf  = 0.97,
    ),
    # ── Credit card (Luhn-valid range heuristic) ─────────────────────
    _Pattern(
        dtype = DetectionType.CARD,
        label = "신용카드",
        regex = re.compile(r"\b(?:\d{4}[\s\-]?){3}\d{4}\b"),
        conf  = 0.88,
    ),
    # ── Korean address keywords ───────────────────────────────────────
    _Pattern(
        dtype = DetectionType.ADDRESS,
        label = "주소",
        regex = re.compile(
            r"(서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충[북남]|전[북남]|경[북남]|제주)"
            r"[\가-힣\s]+(시|군|구|동|읍|면|리|로|길|번지)[\가-힣\d\s\-]*",
        ),
        conf  = 0.80,
    ),
]


class PatternModule:
    """
    Match regex patterns against OCR word text.
    Tries both individual words and adjacent word concatenations for
    split detections (e.g. "010-" on one line, "1234-5678" on next).
    """

    _LINE_GAP_PX = 10  # words within this vertical distance = same line

    def analyze(self, words: List[dict]) -> List[Detection]:
        if not words:
            return []

        detections: List[Detection] = []
        seen_texts: set = set()

        # ── Build line groups ──────────────────────────────────────────
        lines = self._group_lines(words)

        for line in lines:
            # Try three merging strategies + individual words:
            # 1. space-joined  (normal case)
            # 2. no-space join  (split tokens like "010-1234" + "-5678")
            # 3. individual words
            space_text   = " ".join(w["text"] for w in line)
            nospace_text = "".join(w["text"] for w in line)
            candidates = [
                (space_text,   line[0], line[-1]),
                (nospace_text, line[0], line[-1]),
            ] + [
                (w["text"], w, w) for w in line
            ]

            for text, first_word, last_word in candidates:
                text = text.strip()
                if not text or text in seen_texts:
                    continue
                for pat in _PATTERNS:
                    m = pat.regex.search(text)
                    if not m:
                        continue
                    seen_texts.add(text)

                    # Bbox spans from first to last word in candidate
                    x0 = first_word["x"]
                    y0 = first_word["y"]
                    x1 = last_word["x"] + last_word["width"]
                    y1 = max(first_word["y"] + first_word["height"],
                             last_word["y"]  + last_word["height"])
                    bw = x1 - x0
                    bh = y1 - y0

                    # Pad slightly for visual clarity
                    pad = 4
                    detections.append(Detection(
                        id         = _det_id(pat.dtype.value, x0, y0, bw, bh),
                        type       = pat.dtype,
                        label      = pat.label,
                        text       = m.group(0),
                        bbox       = BoundingBox(
                            x=max(0, x0 - pad),
                            y=max(0, y0 - pad),
                            width=bw  + pad * 2,
                            height=bh + pad * 2,
                        ),
                        confidence = pat.conf,
                        source     = "pattern",
                    ))
        return detections

    def _group_lines(self, words: List[dict]) -> List[List[dict]]:
        """Group words into horizontal text lines by y-proximity."""
        if not words:
            return []
        sorted_words = sorted(words, key=lambda w: (w["y"], w["x"]))
        lines:   List[List[dict]] = [[sorted_words[0]]]
        for word in sorted_words[1:]:
            prev_y = lines[-1][-1]["y"]
            if abs(word["y"] - prev_y) <= self._LINE_GAP_PX:
                lines[-1].append(word)
            else:
                lines.append([word])
        return lines


# ═══════════════════════════════════════════════════════════════════════════
# Module 4 — Post-Processor
# ═══════════════════════════════════════════════════════════════════════════

class PostProcessor:
    """
    Merge overlapping detections and remove low-confidence results.
    Deduplication is based on IoU threshold — keeps the detection with
    the highest confidence when two boxes overlap significantly.
    """

    IOU_THRESHOLD       = 0.45
    MIN_CONFIDENCE      = 0.45  # absolute minimum across all sources

    def process(
        self,
        detections: List[Detection],
        img_w:      int,
        img_h:      int,
    ) -> List[Detection]:
        # 1. Remove low confidence
        dets = [d for d in detections if d.confidence >= self.MIN_CONFIDENCE]

        # 2. Clamp coordinates to image bounds
        clamped = []
        for d in dets:
            x, y, w, h = _clamp_bbox(
                d.bbox.x, d.bbox.y, d.bbox.width, d.bbox.height, img_w, img_h,
            )
            clamped.append(d.model_copy(update={"bbox": BoundingBox(x=x, y=y, width=w, height=h)}))

        # 3. IoU-based deduplication
        deduped = self._dedup(clamped)

        # 4. Sort: highest confidence first, then by area
        deduped.sort(
            key=lambda d: (-d.confidence, -(d.bbox.width * d.bbox.height))
        )
        log.debug(
            f"PostProcessor: {len(detections)} → {len(dets)} → {len(deduped)} detections"
        )
        return deduped

    def _dedup(self, dets: List[Detection]) -> List[Detection]:
        if not dets:
            return []
        used   = [False] * len(dets)
        result = []
        # Sort by confidence descending to keep best box when merging
        ordered = sorted(range(len(dets)), key=lambda i: -dets[i].confidence)
        for i in ordered:
            if used[i]:
                continue
            result.append(dets[i])
            for j in ordered:
                if j == i or used[j]:
                    continue
                if _iou(dets[i].bbox, dets[j].bbox) > self.IOU_THRESHOLD:
                    used[j] = True
            used[i] = True
        return result


# ═══════════════════════════════════════════════════════════════════════════
# DetectionEngine — public interface
# ═══════════════════════════════════════════════════════════════════════════

class DetectionEngine:
    """
    Top-level orchestrator.
    Usage:
        engine = DetectionEngine()
        engine.warmup()
        detections = engine.run(numpy_bgr_image)
    """

    # Max dimension for processing (resize large images for performance)
    MAX_DIM = 1280

    def __init__(self) -> None:
        self.face    = FaceModule()
        self.ocr     = OCRModule()
        self.pattern = PatternModule()
        self.post    = PostProcessor()
        self._ready  = False

    def warmup(self) -> None:
        """Load models once at startup."""
        self.face.load()
        self._ready = True
        log.info(
            f"DetectionEngine ready | face:{self.face._source} "
            f"| ocr:{self.ocr.is_available()}"
        )

    @property
    def status(self) -> dict:
        return {
            "face_detector": self.face._source,
            "ocr_available": self.ocr.is_available(),
        }

    def run(self, bgr: np.ndarray) -> Tuple[List[Detection], int, int]:
        """
        Run full detection pipeline.
        Returns (detections, orig_width, orig_height).
        All detection coords are in the ORIGINAL image's pixel space.
        """
        if not self._ready:
            self.warmup()

        orig_h, orig_w = bgr.shape[:2]
        t0 = time.perf_counter()

        # ── Downscale for speed if needed ───────────────────────────────
        scale = 1.0
        proc  = bgr
        max_side = max(orig_w, orig_h)
        if max_side > self.MAX_DIM:
            scale = self.MAX_DIM / max_side
            nw    = int(orig_w * scale)
            nh    = int(orig_h * scale)
            proc  = cv2.resize(bgr, (nw, nh), interpolation=cv2.INTER_AREA)
            log.debug(f"Resized {orig_w}×{orig_h} → {nw}×{nh} (scale={scale:.3f})")

        proc_h, proc_w = proc.shape[:2]

        # ── Face detection ───────────────────────────────────────────────
        face_dets = self.face.detect(proc)

        # ── OCR + pattern matching ───────────────────────────────────────
        words     = self.ocr.extract(proc)
        pat_dets  = self.pattern.analyze(words)

        # ── Post-process ─────────────────────────────────────────────────
        all_dets = face_dets + pat_dets
        all_dets = self.post.process(all_dets, proc_w, proc_h)

        # ── Scale coordinates back to original image space ───────────────
        if scale != 1.0:
            inv = 1.0 / scale
            scaled = []
            for d in all_dets:
                x  = int(d.bbox.x      * inv)
                y  = int(d.bbox.y      * inv)
                w  = int(d.bbox.width  * inv)
                h  = int(d.bbox.height * inv)
                x, y, w, h = _clamp_bbox(x, y, w, h, orig_w, orig_h)
                scaled.append(
                    d.model_copy(update={
                        "bbox": BoundingBox(x=x, y=y, width=w, height=h),
                        # re-compute deterministic ID with original coords
                        "id":   _det_id(d.type.value, x, y, w, h),
                    })
                )
            all_dets = scaled

        ms = (time.perf_counter() - t0) * 1000
        log.info(
            f"DetectionEngine.run: {len(all_dets)} detections "
            f"(face={len(face_dets)} pattern={len(pat_dets)}) "
            f"in {ms:.1f} ms"
        )
        return all_dets, orig_w, orig_h

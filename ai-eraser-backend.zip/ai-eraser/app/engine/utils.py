"""
app/engine/utils.py
Shared image I/O helpers — all in-memory, zero disk writes.
"""

from __future__ import annotations

import io
from typing import Tuple

import cv2
import numpy as np
from PIL import Image


def bytes_to_bgr(data: bytes) -> np.ndarray:
    """Decode image bytes → OpenCV BGR numpy array."""
    arr = np.frombuffer(data, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image — unsupported format or corrupted data")
    return img


def bgr_to_png_bytes(bgr: np.ndarray, quality: int = 95) -> bytes:
    """Encode OpenCV BGR array → PNG bytes (in-memory)."""
    success, buf = cv2.imencode(".png", bgr)
    if not success:
        raise RuntimeError("Failed to encode image to PNG")
    return buf.tobytes()


def bgr_to_jpeg_bytes(bgr: np.ndarray, quality: int = 90) -> bytes:
    """Encode OpenCV BGR array → JPEG bytes (in-memory)."""
    params   = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
    success, buf = cv2.imencode(".jpg", bgr, params)
    if not success:
        raise RuntimeError("Failed to encode image to JPEG")
    return buf.tobytes()


def get_dimensions(bgr: np.ndarray) -> Tuple[int, int]:
    """Return (width, height) of a BGR numpy array."""
    h, w = bgr.shape[:2]
    return w, h


def draw_debug_boxes(bgr: np.ndarray, detections: list) -> np.ndarray:
    """
    Draw bounding boxes on a copy of the image for debugging.
    Not used in production — only for /debug endpoint if enabled.
    """
    from app.models import DetectionType
    COLOR_MAP = {
        DetectionType.FACE:    (52,  211, 153),   # teal
        DetectionType.PHONE:   (251, 191,  36),   # amber
        DetectionType.EMAIL:   ( 56, 189, 248),   # blue
        DetectionType.ID:      (248, 113, 113),   # coral
        DetectionType.CARD:    (192, 132, 252),   # violet
        DetectionType.ADDRESS: (251, 146,  60),   # orange
        DetectionType.TEXT:    (167, 139, 250),   # purple
    }
    out = bgr.copy()
    for det in detections:
        color = COLOR_MAP.get(det.type, (200, 200, 200))
        b     = det.bbox
        cv2.rectangle(out, (b.x, b.y), (b.x + b.width, b.y + b.height), color, 2)
        label = f"{det.label} {int(det.confidence*100)}%"
        cv2.putText(out, label, (b.x, max(b.y - 6, 12)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)
    return out

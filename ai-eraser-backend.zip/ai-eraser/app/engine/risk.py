"""
app/engine/risk.py

RiskScoringEngine — computes a privacy risk score from a list of detections.

Weight table (spec-compliant):
  face    = 20
  phone   = 25
  email   = 15
  id      = 40
  card    = 35
  address = 18
  text    = 10

Score = min(100, Σ weight_i × confidence_i)
Level:
  0–30  → SAFE
  31–70 → WARNING
  71–100→ DANGER
"""

from __future__ import annotations

from typing import Dict, List

from app.models import Detection, DetectionType, RiskLevel, RiskScore

# ── Weight table ────────────────────────────────────────────────────────────
_WEIGHTS: Dict[DetectionType, int] = {
    DetectionType.FACE:    20,
    DetectionType.PHONE:   25,
    DetectionType.EMAIL:   15,
    DetectionType.ID:      40,
    DetectionType.CARD:    35,
    DetectionType.ADDRESS: 18,
    DetectionType.TEXT:    10,
}

# Bonus for high-risk combinations
_COMBOS = [
    ({"phone", "face"},   10, "얼굴+전화번호"),
    ({"email", "id"},     15, "이메일+주민번호"),
    ({"id", "card"},      20, "주민번호+신용카드"),
    ({"face", "id"},      18, "얼굴+주민번호"),
]


def compute_risk(detections: List[Detection]) -> RiskScore:
    """Compute weighted risk score with combo bonuses."""
    if not detections:
        return RiskScore(
            score=0,
            level=RiskLevel.SAFE,
            label_ko="안전",
            breakdown={},
        )

    breakdown: Dict[str, float] = {}
    raw = 0.0

    for det in detections:
        w   = _WEIGHTS.get(det.type, 10)
        pts = w * det.confidence
        raw += pts
        key  = det.type.value
        breakdown[key] = round(breakdown.get(key, 0.0) + pts, 2)

    # Combo bonuses
    types_present = {d.type.value for d in detections}
    for combo_types, bonus, label in _COMBOS:
        if combo_types.issubset(types_present):
            raw += bonus
            breakdown[f"combo:{label}"] = bonus

    score = int(min(100, round(raw)))

    if score <= 30:
        level    = RiskLevel.SAFE
        label_ko = "안전"
    elif score <= 70:
        level    = RiskLevel.WARNING
        label_ko = "주의"
    else:
        level    = RiskLevel.DANGER
        label_ko = "위험"

    return RiskScore(
        score    = score,
        level    = level,
        label_ko = label_ko,
        breakdown= breakdown,
    )

# AI Eraser — Privacy-First Local Redaction System

> **Zero-retention, fully local AI privacy protection.**  
> No image data ever leaves your machine.

---

## Architecture

```
[Upload Image]
     │
     ▼
[ImageLoader]           — validates, resizes for performance
     │
     ▼
[DetectionEngine]
     ├── FaceModule     — Mediapipe Face Detection (→ Haarcascade fallback)
     ├── OCRModule      — Tesseract OCR (word-level bboxes)
     └── PatternModule  — Regex: phone / email / SSN / card / address
     │
     ▼
[PostProcessor]         — IoU dedup, confidence filter, coord clamp
     │
     ▼
[RiskScoringEngine]     — weighted score + combo bonuses → SAFE/WARNING/DANGER
     │
     ▼
[User Validation]       — checkbox per detection, preview bboxes
     │
     ▼
[RedactionEngine]       — blur / pixelate / mosaic (OpenCV pixel ops)
     │
     ▼
[PNG Response]          — in-memory, never stored
```

---

## Quick Start

### 1. System dependencies

**Ubuntu / Debian**
```bash
sudo apt update
sudo apt install -y tesseract-ocr tesseract-ocr-kor tesseract-ocr-eng \
                    libgl1-mesa-glx libglib2.0-0
```

**macOS**
```bash
brew install tesseract tesseract-lang
```

**Windows**  
Download installer: https://github.com/UB-Mannheim/tesseract/wiki  
Add to PATH.

### 2. Python dependencies
```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Run the server
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 4. Open the frontend
Navigate to: **http://localhost:8000**  
API docs: **http://localhost:8000/docs**

---

## API Reference

### `POST /api/analyze`
Detect sensitive regions in an image.

**Request:** `multipart/form-data`
- `file`: image file (JPEG / PNG / WEBP, max 20 MB)

**Response:**
```json
{
  "detections": [
    {
      "id": "a3f7b2c1d4e5",
      "type": "face",
      "label": "얼굴",
      "bbox": { "x": 120, "y": 80, "width": 200, "height": 180 },
      "confidence": 0.94,
      "source": "mediapipe",
      "selected": true
    }
  ],
  "risk": {
    "score": 74,
    "level": "DANGER",
    "label_ko": "위험",
    "breakdown": { "face": 18.0, "id": 38.8, "combo:얼굴+주민번호": 18 }
  },
  "image_width": 1280,
  "image_height": 960,
  "processing_ms": 312.5
}
```

---

### `POST /api/redact`
Apply redaction to selected detections.

**Request:** `multipart/form-data`
- `file`: original image
- `detections`: JSON array (from `/analyze`, set `selected: false` to skip)
- `mode`: `blur` | `pixelate` | `mosaic`  (default: `blur`)
- `blur_strength`: 5–80  (default: 25)
- `pixel_size`: 5–50  (default: 15)

**Response:** PNG image (`image/png`)

---

### `GET /api/health`
```json
{
  "status": "ok",
  "face_detector": "mediapipe",
  "ocr_available": true,
  "version": "1.0.0"
}
```

---

## Detection Modules

| Module | Library | Detects |
|--------|---------|---------|
| FaceModule | Mediapipe / Haarcascade | Human faces |
| OCRModule | Tesseract | Text in image |
| PatternModule | Regex | Phone, email, SSN, credit card, address |

---

## Risk Scoring

| Type | Weight |
|------|--------|
| face | 20 |
| phone | 25 |
| email | 15 |
| id (SSN) | 40 |
| card | 35 |
| address | 18 |

Combo bonuses: `face+id (+18)`, `id+card (+20)`, `email+id (+15)`

Score 0–30 → **SAFE** · 31–70 → **WARNING** · 71–100 → **DANGER**

---

## Redaction Modes

| Mode | Algorithm |
|------|-----------|
| `blur` | Gaussian blur (`cv2.GaussianBlur`) |
| `pixelate` | Downsample → upsample (nearest-neighbor) |
| `mosaic` | Average color per NxN block |

---

## Security

- Images are processed **entirely in memory** — no temp files
- No logging of image content or extracted text
- Response headers include `Cache-Control: no-store`
- Following **data minimization** and **zero-retention** principles

---

## Project Structure

```
ai-eraser/
├── main.py                   ← FastAPI app factory + lifespan
├── requirements.txt
├── static/
│   └── index.html            ← Frontend (served by FastAPI)
├── app/
│   ├── models.py             ← Pydantic schemas
│   ├── engine/
│   │   ├── detection.py      ← FaceModule + OCRModule + PatternModule
│   │   ├── risk.py           ← RiskScoringEngine
│   │   ├── redaction.py      ← BlurEngine (blur / pixelate / mosaic)
│   │   └── utils.py          ← Image I/O helpers
│   └── routers/
│       ├── analyze.py        ← POST /api/analyze
│       ├── redact.py         ← POST /api/redact
│       └── health.py         ← GET /api/health
└── tests/
    └── test_engines.py       ← pytest unit tests
```

---

## Extensibility

**Video (frame-based)**
```python
cap = cv2.VideoCapture("video.mp4")
while True:
    ret, frame = cap.read()
    if not ret: break
    dets, w, h = engine.run(frame)
    # redact + write frame
```

**PDF (page-based)**
```python
# pip install pdf2image
from pdf2image import convert_from_path
pages = convert_from_path("doc.pdf")
for page in pages:
    bgr = cv2.cvtColor(np.array(page), cv2.COLOR_RGB2BGR)
    dets, w, h = engine.run(bgr)
```

**Kakao Bot webhook**
```python
@app.post("/kakao/webhook")
async def kakao(request: Request):
    data = await request.json()
    image_url = data["userRequest"]["utterance"]  # or file attachment
    # fetch + run + return redacted
```
